# py-aws-demo
CI-CD integrated Python application with deployment against AWS
